/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioauto;

import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Automovil;

/**
 *
 * @author pc-Profesor2
 */
public class Inicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // TODO code application logic here
            Automovil car=new Automovil("Lada", "Samara", 1901, 50);
            /*car.setMarca("Lada");
            car.setModelo("Samara");
            car.setAño(1990);
            car.setGasolina(150);*/
            System.out.println(car.verDetalles());
        } catch (Exception ex) {
            Logger.getLogger(Inicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
