/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author pc-Profesor2
 */
public class Automovil {

    private String marca;//no vacio
    private String modelo;//no vacio
    private int año;//mayor 1900
    private double gasolina;//entre 0 y 100

    /*public Automovil() {

    }*/
    
    public Automovil(String marca,String modelo,int año,double gasolina) throws Exception{
        this.setMarca(marca);
        this.setModelo(modelo);
        this.setAño(año);
        this.setGasolina(gasolina);
    }

    public String getMarca() {
        return this.marca;
    }

    public void setMarca(String marca) throws Exception {
        if (!marca.isBlank() && !marca.isEmpty()) {
            this.marca = marca;
        } else {
            throw new Exception("Debe agregar marca");
        }
    }

    public String getModelo() {
        return this.modelo;
    }

    public void setModelo(String modelo) throws Exception {
        if (!modelo.isBlank() && !modelo.isEmpty()) {
            this.modelo = modelo;
        } else {
            throw new Exception("Debe agregar modelo");
        }
    }

    public int getAño() {
        return año;

    }

    public void setAño(int año) throws Exception {
        if (año > 1900) {
            this.año = año;
        } else {
            throw new Exception("Año debe ser mayor a 1900");
        }
    }

    public double getGasolina() {
        return this.gasolina;
    }

    public void setGasolina(double gasolina) throws Exception {
        if (gasolina >= 0 && gasolina <= 100) {
            this.gasolina = gasolina;
        } else {
            throw new Exception("Gasolina debde estar entre 0 y 100");
        }
    }
    
    public String verDetalles()
    {
        return  "Marca: " + this.marca +
                "\nModelo: " + this.modelo +
                "\nAño: " + this.año +
                "\nGasolina: " + this.gasolina;
        
    }

}
